oh-my-posh init pwsh --config 'D:\Software\oh-my-posh\powerlevel10k_rainbow.omp.json' | Invoke-Expression
Import-Module Terminal-Icons
Import-Module PSReadLine
Set-PSReadLineOption -EditMode Windows
Set-PSReadLineOption -PredictionViewStyle ListView
Set-PSReadLineOption -PredictionSource History